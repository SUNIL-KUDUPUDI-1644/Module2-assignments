import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Movie } from './Movie';

@Injectable({
  providedIn: 'root'
})
export class MsService {
movie:Movie;

  constructor(private httpClient:HttpClient) { 
 
  this.getmovieDetails().subscribe(data => this.movieList = data);}

movieList: Array<Movie> = [];

url: string = "/assets/movie.json";
getmovieDetails(): any {
  return this.httpClient.get<Movie>(this.url);
}


setmovieDetails(movie: Movie) {
  this.movieList.push(movie);
console.log(this.movieList)
}
myArray: Array<Movie>;


search(data):any[]
{
  this.myArray=[];
for(let movie of this.movieList)
{

  if(movie.genre==data.genre)
  {
    this.myArray.push(movie);
  }
}

return (this.myArray)
}
}